export default function Contact() {
  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: 24 }}>
      <h1>Contact</h1>
      <p>For demo inquiries:</p>
      <ul>
        <li>Telegram: @your_username</li>
        <li>Email: demo@example.com</li>
      </ul>
    </div>
  );
}
